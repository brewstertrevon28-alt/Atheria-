# Atheria: Chronicles of the Void — Android Prototype v0.1

Native Kotlin + Jetpack Compose, landscape RPG prototype.

## Open and run
1. Install Android Studio with Android SDK 35 and JDK 17.
2. Open the `AtheriaAndroid` folder in Android Studio.
3. Allow Gradle sync to download dependencies.
4. Run the `app` configuration on an emulator or Android device (Android 8.0+).

## Features
- Horizontal forest-scene parallax illusion controlled by Move East / West
- Forest Wolf and Pack Alpha turn-based encounters
- Sword and Gluttony attacks; HP, XP, gold, level-ups
- Chapter quest and Pack Killer title unlock
- Temporary canvas art (no copyrighted assets)

## Prototype limitations
- No save system, animations, sound, dialogue trees, inventory, party system, or touch joystick yet.
- Movement is button-driven, not continuous scrolling.
- The project is source code, not a prebuilt APK. It has not been compiled in this environment.
