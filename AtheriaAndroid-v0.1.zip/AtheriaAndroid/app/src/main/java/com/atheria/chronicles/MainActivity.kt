package com.atheria.chronicles

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlin.math.min

private val Night = Color(0xFF11182B)
private val Gold = Color(0xFFFFD47D)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { AtheriaGame() } }
    }
}

@Composable
private fun AtheriaGame() {
    var distance by remember { mutableIntStateOf(0) }
    var level by remember { mutableIntStateOf(1) }
    var xp by remember { mutableIntStateOf(0) }
    var gold by remember { mutableIntStateOf(0) }
    var hp by remember { mutableIntStateOf(100) }
    var enemyHp by remember { mutableIntStateOf(0) }
    var enemyMax by remember { mutableIntStateOf(0) }
    var enemyName by remember { mutableStateOf("") }
    var battle by remember { mutableStateOf(false) }
    var finished by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("Shuien awakens in Verdant Forest. Travel east.") }

    fun startBattle() {
        battle = true
        val boss = distance >= 12
        enemyName = if (boss) "Pack Alpha" else "Forest Wolf"
        enemyMax = if (boss) 75 else 35
        enemyHp = enemyMax
        message = "A $enemyName blocks the path!"
    }
    fun attack(special: Boolean) {
        if (!battle) return
        val damage = (if (special) 23 else 12) + level * 3
        enemyHp = (enemyHp - damage).coerceAtLeast(0)
        if (enemyHp == 0) {
            battle = false
            val boss = enemyName == "Pack Alpha"
            gold += if (boss) 100 else 15
            xp += if (boss) 65 else 25
            if (xp >= level * 50) {
                xp -= level * 50
                level++
                hp = 100
                message = "Victory! Level up to $level!"
            } else message = "Victory! Earned XP and gold."
            if (boss) { finished = true; message = "Quest complete: Pack Killer title unlocked!" }
        } else {
            val incoming = if (enemyName == "Pack Alpha") 17 else 9
            hp = (hp - incoming).coerceAtLeast(0)
            message = if (special) "Gluttony Strike hits for $damage! Enemy counters for $incoming." else "Sword strike hits for $damage! Enemy counters for $incoming."
            if (hp == 0) {
                battle = false
                hp = 100
                distance = (distance - 3).coerceAtLeast(0)
                message = "Defeated! You recover at a forest clearing."
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Night).padding(12.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("ATHERIA  •  VERDANT FOREST", color = Gold, fontWeight = FontWeight.Bold)
            Text("Shuien  Lv.$level   HP $hp/100   XP $xp/${level * 50}   Gold $gold", color = Color.White)
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            ForestScene(distance, battle, enemyHp, enemyMax, Modifier.fillMaxSize())
            if (battle) Text("$enemyName  HP $enemyHp/$enemyMax", Modifier.align(Alignment.TopCenter).background(Night.copy(alpha = .85f), RoundedCornerShape(8.dp)).padding(8.dp), color = Gold)
            if (finished) Text("CHAPTER COMPLETE • PACK KILLER", Modifier.align(Alignment.Center).background(Night).padding(18.dp), color = Gold)
        }
        Text(message, color = Color.White)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            if (battle) {
                Button(onClick = { attack(false) }) { Text("Sword Attack") }
                Button(onClick = { attack(true) }) { Text("Gluttony Strike") }
            } else if (!finished) {
                Button(onClick = {
                    distance++
                    message = "Exploring Verdant Forest • Step $distance"
                    if (distance % 3 == 0 || distance >= 12) startBattle()
                }) { Text("Move East →") }
                Button(onClick = { distance = (distance - 1).coerceAtLeast(0); message = "You retrace your steps." }) { Text("← West") }
                Button(onClick = { hp = min(100, hp + 25); message = "You rest and recover 25 HP." }) { Text("Rest") }
            } else {
                Button(onClick = { distance = 0; level = 1; xp = 0; gold = 0; hp = 100; finished = false; message = "A new journey begins." }) { Text("Play Again") }
            }
            Spacer(Modifier.weight(1f))
            Text("Quest: Defeat the Pack Alpha ($distance/12)", color = Gold)
        }
    }
}

@Composable
private fun ForestScene(distance: Int, battle: Boolean, enemyHp: Int, enemyMax: Int, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height
        drawRect(Color(0xFF273C5B))
        drawCircle(Color(0xFFFFE6AB), radius = h * .10f, center = Offset(w * .83f, h * .19f))
        for (i in 0..10) {
            val x = ((i * w / 7f - distance * 35f) % (w + w / 5f) + w + w / 5f) % (w + w / 5f)
            drawRect(Color(0xFF493B40), Offset(x, h * .37f), Size(w * .035f, h * .43f))
            drawCircle(Color(0xFF245B51), h * .19f, Offset(x + w * .017f, h * .30f))
        }
        drawRect(Color(0xFF324C38), Offset(0f, h * .78f), Size(w, h * .22f))
        drawRect(Color(0xFF536C42), Offset(0f, h * .78f), Size(w, h * .025f))
        // Shuien placeholder sprite
        val px = w * .25f; val py = h * .73f
        drawCircle(Color(0xFFF1D0B4), h * .055f, Offset(px, py - h * .23f))
        drawRect(Color(0xFF25253B), Offset(px - w * .025f, py - h * .18f), Size(w * .05f, h * .17f))
        drawRect(Color(0xFF202536), Offset(px - w * .02f, py - h * .01f), Size(w * .016f, h * .08f))
        drawRect(Color(0xFF202536), Offset(px + w * .004f, py - h * .01f), Size(w * .016f, h * .08f))
        drawLine(Gold, Offset(px + w * .028f, py - h * .15f), Offset(px + w * .08f, py - h * .37f), strokeWidth = 5f)
        if (battle) {
            val ex = w * .73f; val ey = h * .70f
            drawCircle(Color(0xFF9A5967), h * .09f, Offset(ex, ey - h * .12f))
            drawCircle(Color(0xFFCF8C81), h * .045f, Offset(ex - w * .035f, ey - h * .20f))
            drawCircle(Color(0xFFCF8C81), h * .045f, Offset(ex + w * .035f, ey - h * .20f))
            drawRect(Color(0xFF9A5967), Offset(ex - w * .055f, ey - h * .09f), Size(w * .11f, h * .10f))
            drawRect(Color.Red, Offset(ex - w * .06f, ey - h * .33f), Size(w * .12f * enemyHp.toFloat() / enemyMax.coerceAtLeast(1), 6f))
            drawRect(Color.White, Offset(ex - w * .06f, ey - h * .33f), Size(w * .12f, 6f), style = Stroke(1f))
        }
    }
}
