# Atheria: Chronicles of the Void — Firebase Studio Edition

A mobile-friendly React + TypeScript + Vite story RPG prototype inspired by classic party-based fantasy RPGs. Uses original Atheria lore. No Firebase account, backend, or paid service is required to preview the prototype.

## Open in Firebase Studio (studio.firebase.google.com)
1. Download and unzip this project.
2. Create a new workspace in Firebase Studio, choosing a blank or React/TypeScript workspace (if available).
3. Upload or copy these project files into the workspace root. Alternatively, push the unzipped folder to GitHub and import that repository into Firebase Studio.
4. In the terminal run `npm install` then `npm run dev`.
5. Open the workspace web preview (port 3000). Use the preview's mobile view or open it on an Android browser.

## Build
`npm run build` generates static web files in `dist/`. For Android APK packaging later, add Capacitor or a Trusted Web Activity build workflow.

## Gameplay
Tap East/West to explore. Every 20% of exploration, a wolf encounter occurs until the Pack Alpha appears after three wolf wins. Tap attacks to battle; Guard reduces the next retaliation. Defeating the Pack Alpha unlocks the Pack Killer title. Progress saves in browser localStorage. Reset Save clears progress.

## Notes
- This is a playable browser game, not yet an installable Android APK.
- Firebase Studio is a browser development environment; it does not automatically convert React projects into APKs.
- Emoji and CSS are temporary art placeholders.
- More story chapters, sprites, parties, equipment, and server sync are future work.
